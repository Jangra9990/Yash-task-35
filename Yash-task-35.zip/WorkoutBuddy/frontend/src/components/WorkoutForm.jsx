import { useState, useContext } from "react";
import { WorkoutContext } from "../context/WorkoutContext";
import { Plus } from "lucide-react";

const WorkoutForm = () => {
    const { dispatch } = useContext(WorkoutContext);

    const [title, setTitle] = useState("");
    const [load, setLoad] = useState("");
    const [reps, setReps] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!title.trim() || load === "" || reps === "") {
            setError("Please fill in all fields");
            return;
        }

        if (!Number.isFinite(Number(load)) || Number(load) < 0) {
            setError("Load must be a valid non-negative number");
            return;
        }

        if (!Number.isInteger(Number(reps)) || Number(reps) < 1) {
            setError("Reps must be a positive whole number");
            return;
        }

        setLoading(true);

        try {
            const response = await fetch("http://localhost:5000/api/workouts", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    title: title.trim(),
                    load: Number(load),
                    reps: Number(reps)
                })
            });

            const json = await response.json();

            if (!response.ok) {
                setError(json.error || "Unable to create workout");
                return;
            }

            dispatch({
                type: "CREATE_WORKOUT",
                payload: json
            });

            setTitle("");
            setLoad("");
            setReps("");

        } catch (error) {
            setError("Unable to connect to server");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="form-card">
            <h2>Add a New Workout</h2>
            <p className="form-subtitle">Track your progress and stay consistent.</p>

            <form onSubmit={handleSubmit}>
                <label>Workout Title</label>
                <input
                    type="text"
                    placeholder="e.g. Chest, Hamstrings"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />

                <label>Load (in kg)</label>
                <input
                    type="number"
                    min="0"
                    step="any"
                    placeholder="Enter weight"
                    value={load}
                    onChange={(e) => setLoad(e.target.value)}
                />

                <label>Reps</label>
                <input
                    type="number"
                    min="1"
                    step="1"
                    placeholder="Enter repetitions"
                    value={reps}
                    onChange={(e) => setReps(e.target.value)}
                />

                {error && <p className="error-message">{error}</p>}

                <button className="add-btn" type="submit" disabled={loading}>
                    <Plus size={19} />
                    {loading ? "Adding..." : "Add Workout"}
                </button>
            </form>
        </div>
    );
};

export default WorkoutForm;