import { useContext } from "react";
import { WorkoutContext } from "../context/WorkoutContext";
import { Trash2, Dumbbell } from "lucide-react";

const WorkoutDetails = ({ workout }) => {
    const { dispatch } = useContext(WorkoutContext);

    const handleDelete = async () => {
        const response = await fetch(
            `http://localhost:5000/api/workouts/${workout._id}`,
            {
                method: "DELETE"
            }
        );

        const json = await response.json();

        if (!response.ok) {
            alert(json.error);
            return;
        }

        dispatch({
            type: "DELETE_WORKOUT",
            payload: workout
        });
    };

    const timeAgo = (date) => {
        const seconds = Math.floor((new Date() - new Date(date)) / 1000);

        if (seconds < 60) return "just now";
        if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
        if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;

        return `${Math.floor(seconds / 86400)} days ago`;
    };

    return (
        <div className="workout-card">
            <div className="card-top">
                <div className="workout-icon">
                    <Dumbbell size={22} />
                </div>

                <button className="delete-btn" onClick={handleDelete}>
                    <Trash2 size={19} />
                </button>
            </div>

            <h3>{workout.title}</h3>

            <div className="workout-info">
                <div>
                    <span>Load</span>
                    <strong>{workout.load} kg</strong>
                </div>

                <div>
                    <span>Reps</span>
                    <strong>{workout.reps}</strong>
                </div>
            </div>

            <p className="created-time">
                Created {timeAgo(workout.createdAt)}
            </p>
        </div>
    );
};

export default WorkoutDetails;