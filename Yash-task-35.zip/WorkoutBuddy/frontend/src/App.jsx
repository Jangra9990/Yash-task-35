import { useContext, useEffect, useState } from "react";
import { WorkoutContext } from "./context/WorkoutContext";
import WorkoutDetails from "./components/WorkoutDetails";
import WorkoutForm from "./components/WorkoutForm";
import { Dumbbell } from "lucide-react";

const App = () => {
    const { workouts, dispatch } = useContext(WorkoutContext);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchWorkouts = async () => {
            try {
                const response = await fetch("http://localhost:5000/api/workouts");
                const json = await response.json();

                if (!response.ok) {
                    setError(json.error || "Unable to fetch workouts");
                    return;
                }

                dispatch({
                    type: "SET_WORKOUTS",
                    payload: json
                });

            } catch (error) {
                setError("Unable to connect to server");
            } finally {
                setLoading(false);
            }
        };

        fetchWorkouts();
    }, [dispatch]);

    return (
        <div className="app">
            <header className="header">
                <div className="logo">
                    <Dumbbell size={27} />
                    <h2>Workout Buddy</h2>
                </div>
                <span className="header-tag">Your Fitness Tracker</span>
            </header>

            <main className="main-container">
                <section className="workouts-section">
                    <div className="section-heading">
                        <div>
                            <p className="small-heading">YOUR ACTIVITY</p>
                            <h1>My Workouts</h1>
                        </div>

                        <span className="workout-count">
                            {workouts.length} Workouts
                        </span>
                    </div>

                    {error && <p className="error-message">{error}</p>}

                    {loading ? (
                        <p className="empty-message">Loading workouts...</p>
                    ) : workouts.length > 0 ? (
                        <div className="workouts-grid">
                            {workouts.map((workout) => (
                                <WorkoutDetails
                                    key={workout._id}
                                    workout={workout}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="empty-state">
                            <Dumbbell size={38} />
                            <h3>No workouts yet</h3>
                            <p>Add your first workout to get started.</p>
                        </div>
                    )}
                </section>

                <aside className="form-section">
                    <WorkoutForm />
                </aside>
            </main>
        </div>
    );
};

export default App;