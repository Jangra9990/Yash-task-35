Workout Buddy

Workout Buddy is a workout tracking application built using React, Node.js, Express.js, and MongoDB.

 Features
 Add new workouts with title, load, and reps.
 View all workouts.
 Delete workouts.
 Display workout creation time.
 Responsive design for desktop and mobile.
 Global state management using React Context API and useReducer.
 Backend validation and error handling.

 Technologies Used

Frontend: React.js, CSS, Context API, useReducer

Backend: Node.js, Express.js

Database: MongoDB Atlas, Mongoose

 Project Structure

WorkoutBuddy

backend

frontend

README.md

Installation and Setup

 Backend Setup

Open terminal and navigate to the backend folder.

    cd backend

Install dependencies.

    npm install

Create a .env file inside the backend folder.

Add the following details.

    PORT=5000
    MONGO_URI=your_mongodb_atlas_connection_string

Start the backend server.

    npm run dev

 Frontend Setup

Open another terminal and navigate to the frontend folder.

    cd frontend

Install dependencies.

    npm install

Start the React application.

    npm run dev

Open the local URL provided by Vite in your browser.

API Endpoints

GET /api/workouts

Fetch all workouts.

POST /api/workouts

Create a new workout.

DELETE /api/workouts/:id

Delete a workout by ID.

State Management

React Context API and useReducer are used to manage the global workout state.

The application supports setting, adding, and removing workouts.

 Database

MongoDB Atlas is used to store workout details.

Each workout contains title, load, reps, createdAt, and updatedAt fields.

 Author

Yash