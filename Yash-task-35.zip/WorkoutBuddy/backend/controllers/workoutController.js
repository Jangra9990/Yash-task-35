const Workout = require("../models/workoutModel");

const getWorkouts = async (req, res) => {
    try {
        const workouts = await Workout.find().sort({ createdAt: -1 });
        res.status(200).json(workouts);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const createWorkout = async (req, res) => {
    try {
        const { title, load, reps } = req.body;

        if (!title || load === undefined || load === "" || reps === undefined || reps === "") {
            return res.status(400).json({
                error: "All fields are required"
            });
        }

        if (typeof title !== "string" || !title.trim()) {
            return res.status(400).json({
                error: "Please enter a valid workout title"
            });
        }

        const workout = await Workout.create({
            title: title.trim(),
            load,
            reps
        });

        res.status(201).json(workout);
    } catch (error) {
        if (error.name === "ValidationError" || error.name === "CastError") {
            return res.status(400).json({
                error: error.message
            });
        }

        res.status(500).json({
            error: "Something went wrong"
        });
    }
};

const deleteWorkout = async (req, res) => {
    try {
        const workout = await Workout.findByIdAndDelete(req.params.id);

        if (!workout) {
            return res.status(404).json({
                error: "Workout not found"
            });
        }

        res.status(200).json(workout);
    } catch (error) {
        if (error.name === "CastError") {
            return res.status(400).json({
                error: "Invalid workout ID"
            });
        }

        res.status(500).json({
            error: error.message
        });
    }
};

module.exports = {
    getWorkouts,
    createWorkout,
    deleteWorkout
};